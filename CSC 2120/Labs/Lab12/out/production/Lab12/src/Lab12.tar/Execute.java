public interface Execute<T>{
    public void execute(Command<T> item);
}
