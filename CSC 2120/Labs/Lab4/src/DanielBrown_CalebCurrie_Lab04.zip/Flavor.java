
public enum Flavor 
{
   chocolate, vanilla, coffee, mint_chocolate_chip, almond_fudge, pistachio_almond, 
   pralines_and_cream, cherries_jubilee, oreo_cookies_and_cream, peanut_butter_and_chocolate, 
   chocolate_chip, very_berry_strawberry, rocky_road, butter_pecan, chocolate_fudge, french_vanilla, 
   nutty_coconut, truffle_in_paradise;
}